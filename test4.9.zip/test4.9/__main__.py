"""Bootstrap script for Amazon Linux to comply CIS Amazon Linux Benchmark v2.0.0"""

import argparse
import logging
import os
import re
from subprocess import CalledProcessError
import pkg_resources

from util import exec_shell, set_backup_enabled, File, Package, Service, PropertyFile


def get_string_asset(path):
    """Returns the content of the specified asset file"""
    return pkg_resources.resource_string(__name__, 'assets/{}'.format(path))


def disable_unused_filesystems():
    """1.1.1 Disable unused filesystems"""
    print("Disabling unused filesystems - 1.1.1")
    filesystems = [
        'cramfs', 'freevxfs', 'jffs2', 'hfs', 'hfsplus', 'squashfs', 'udf', 'vfat'
    ]

    prop = PropertyFile('/etc/modprobe.d/CIS.conf', ' ')
    for filesystem in filesystems:
        prop.override({'install {}'.format(filesystem): '/bin/true'})
    prop.write()


def set_mount_options():
    """1.1.2 - 1.1.17"""
    print("Setting mount options - 1.1.2 - 1.1.17")
    options = {
        '/tmp': 'tmpfs /tmp tmpfs rw,nosuid,nodev,noexec,relatime 0 0',
        '/var/tmp': 'tmpfs /var/tmp tmpfs rw,nosuid,nodev,noexec,relatime 0 0',
        '/home': '/dev/xvdf1 /home ext4 rw,nodev,relatime,data=ordered 0 0',
        '/dev/shm': 'tmpfs /dev/shm tmpfs rw,nosuid,nodev,noexec,relatime 0 0'
    }

    with open('/etc/fstab', 'r') as f:
        for line in f:
            if line.startswith('#'):
                continue
            partition = line.split()[1]
            if partition not in options:
                options[partition] = line.strip()

    with open('/etc/fstab', 'w') as f:
        for record in options.values():
            f.write('{}\n'.format(record))


def ensure_sticky_bit():
    """1.1.18 Ensure sticky bit is set on all world - writable directories"""
    print("Ensuring sticky bit is set on all world - writable directories - 1.1.18")
    try:
        return exec_shell(['df --local -P | awk {\'if (NR!=1) print $6\'} | xargs -I \'{}\' find \'{}\' -xdev -type d -perm -0002 2>/dev/null | xargs chmod a+t'])
    except CalledProcessError:
        return 1


#def disable_automounting():
    """1.1.19 Disable Automounting"""
 #   Service('autofs').disable()


def enable_aide():
    """1.3 Filesystem Integrity Checking"""
    print("Enabling Filesystem Integrity Checking AIDE - 1.3")

    cron_job = '0 5 * * * /usr/sbin/aide --check'

    Package('aide').install()

    return exec_shell([
        'aide --init',
        'mv /var/lib/aide/aide.db.new.gz /var/lib/aide/aide.db.gz',
        '(crontab -u root -l 2>/dev/null | grep -v /usr/sbin/aide; echo "{}") | crontab -'.format(cron_job)
    ])


def secure_boot_settings():
    """1.4 Secure Boot Settings"""
    print("Securing boot settings - 1.4")

    if os.path.isfile('/boot/grub/menu.lst'):
        exec_shell([
            'chown root:root /boot/grub/menu.lst',
            'chmod og-rwx /boot/grub/menu.lst'
        ])

    PropertyFile('/etc/sysconfig/init', '=').override({
        'SINGLE': '/sbin/sulogin',
        'PROMPT': 'no'
    }).write()


def apply_process_hardenings():
    """1.5 Additional Process Hardening"""
    print("Additional Process Hardening - 1.5.1, 1.5.3 and 1.5.4")
    # 1.5.1 Ensure core dumps are restricted
    PropertyFile('/etc/security/limits.conf', ' ').override({
        '* hard core': '0'
    }).write()

    PropertyFile('/etc/sysctl.conf', ' = ').override({
        'fs.suid_dumpable': '0'
    }).write()

    # 1.5.3 Ensure address space layout randomization (ASLR) is enable
    PropertyFile('/etc/sysctl.conf', ' = ').override({
        'kernel.randomize_va_space': '2'
    }).write()

    # 1.5.4 Ensure prelink is disabled
    Package('prelink').remove()


def configure_warning_banners():
    """1.7 Warning Banners"""
    print("Setting up warning banners - 1.7")

    # 1.7.1 Command Line Warning Banners
    exec_shell([
        'update-motd --disable',
        'chown root:root /etc/motd',
        'chmod 644 /etc/motd'
    ])
    File('/etc/motd').write(get_string_asset('/etc/motd'))

    exec_shell(['chown root:root /etc/issue', 'chmod 644 /etc/issue'])
    File('/etc/issue').write('Authorized uses only. All activity may be monitored and reported.\n')

    exec_shell(['chown root:root /etc/issue.net', 'chmod 644 /etc/issue.net'])
    File('/etc/issue.net').write('Authorized uses only. All activity may be monitored and reported.\n')


def ensure_updated():
    """1.8 Ensure updates, patches, and additional security software are installed"""
    print("Ensuring updates, patches, and additional security software are installed - 1.8")
    Package.update_all()


def disable_inetd_services():
    """2.1 inetd Services"""
    print("Disabling inetd services - 2.1")
    
    services = [
        'chargen-dgram', 'chargen-stream', 'daytime-dgram', 'daytime-stream',
        'discard-dgram', 'discard-stream', 'echo-dgram', 'echo-stream',
        'time-dgram', 'time-stream', 'rexec', 'rlogin', 'rsh', 'talk',
        'telnet', 'tftp', 'rsync', 'xinetd'
    ]

    for srv in services:
        Service(srv).disable()


def remove_x11_packages():
    """2.2.2 Ensure X Window System is not installed"""
    print("Removing X11 packages - 2.2.2")
    Package('xorg-x11*').remove()


def disable_special_services():
    """2.2.3 - 2.2.14, 2.2.16"""
    print("Disabling special services - 2.2.3 - 2.2.16 and 2.2.16")
    services = [
        'avahi-daemon', 'cups',
        'dhcpd', 'slapd', 'nfs', 'rpcbind', 'named', 'vsftpd',
        'httpd', 'dovecot', 'smb', 'squid', 'snmpd', 'ypserv'
    ]

    for srv in services:
        Service(srv).disable()


def configure_mta():
    """2.2.15 Ensure mail transfer agent is configured for local - only mode"""
    print("Ensuring mail transfer agent is configured for local - only mode - 2.2.15")
    
    exec_shell([
        'mkdir -p /etc/postfix',
        'touch /etc/postfix/main.cf'
    ])
    PropertyFile('/etc/postfix/main.cf', ' = ').override({
        'inet_interfaces': 'localhost'
    }).write()


def remove_insecure_clients():
    """2.3 Service Clients"""
    print("Removing insecure clients - 2.3")
    
    packages = [
        'ypbind', 'rsh', 'talk',
        'telnet', 'openldap-clients'
    ]

    for package in packages:
        Package(package).remove()



def configure_host_network_params():
    """3.1 Network Parameters(Host Only)"""
    print("Configuring host network parameters (Host Only) - 3.1.1")
    
    PropertyFile('/etc/sysctl.conf', ' = ').override({
        
        'net.ipv4.ip_forward': '0',
        'net.ipv4.conf.all.send_redirects': '0',
        'net.ipv4.conf.default.send_redirects': '0',
        'net.ipv6.conf.all.forwarding': '0'             # --> 3.1.1 change added
        
    }).write()
    
    
    exec_shell([
        
        'sysctl -w net.ipv4.ip_forward=0',
        'sysctl -w net.ipv6.conf.all.forwarding=0',
        'sysctl -w net.ipv4.route.flush=1',                   #3.1.1 changes added
        'sysctl -w net.ipv6.route.flush=1'
        
    ])

def configure_network_params():
    """3.2 Network Parameters(Host and Router)"""
    print("Configuring host network parameters (Host and Router) - 3.2.1")
    
    PropertyFile('/etc/sysctl.conf', ' = ').override({
        'net.ipv4.conf.all.accept_source_route': '0',
        'net.ipv4.conf.default.accept_source_route': '0',           # 3.2.1
        'net.ipv4.conf.all.accept_redirects': '0',                  #'net.ipv4.conf.all.accept_source_route': '0',      --> already present
        'net.ipv4.conf.default.accept_redirects': '0',              #'net.ipv4.conf.default.accept_source_route': '0',  --> already present
        'net.ipv4.conf.all.secure_redirects': '0',
        'net.ipv4.conf.default.secure_redirects': '0',
        'net.ipv4.conf.all.log_martians': '1',
        'net.ipv4.conf.default.log_martians': '1',
        'net.ipv4.icmp_echo_ignore_broadcasts': '1',
        'net.ipv4.icmp_ignore_bogus_error_responses': '1',
        'net.ipv4.conf.all.rp_filter': '1',
        'net.ipv4.conf.default.rp_filter': '1',
        'net.ipv4.tcp_syncookies': '1',
        'net.ipv6.conf.all.accept_source_route': '0',       #  --> change
        'net.ipv6.conf.default.accept_source_route': '0'    #  --> change 
        
    }).write()
    
    exec_shell([
        'sysctl -w net.ipv4.conf.all.accept_source_route=0',            #  --> full function is new
        'sysctl -w net.ipv4.conf.default.accept_source_route=0',
        'sysctl -w net.ipv6.conf.all.accept_source_route=0',
        'sysctl -w net.ipv6.conf.default.accept_source_route=0',        # 3.2.1 changes added
        'sysctl -w net.ipv4.route.flush=1',
        'sysctl -w net.ipv6.route.flush=1'
    ])


def configure_ipv6_params():
    """3.3 IPv6"""
    print("Configuring IPv6 parameters - 3.3.3")
    
    PropertyFile('/etc/sysctl.conf', ' = ').override({
        'net.ipv6.conf.all.accept_ra': '0',
        'net.ipv6.conf.default.accept_ra': '0',
        'net.ipv6.conf.all.accept_redirects': '0',
        'net.ipv6.conf.default.accept_redirects': '0'
    }).write()

    # 3.3.3 Ensure IPv6 is disabled
    PropertyFile('/etc/modprobe.d/CIS.conf', ' ').override({
        'options ipv6': 'disable=1'
    }).write()


def configure_tcp_wrappers(hosts):
    """3.4 TCP Wrappers"""
    print("Configuring TCP Wrappers - 3.4.1 - 3.4.5")
    # 3.4.1 Ensure TCP Wrappers is installed
    Package('tcp_wrappers').install()

    if hosts:
        # 3.4.2 Ensure /etc/hosts.allow is configured
        allowed_hosts = ','.join(hosts)
        exec_shell('echo "ALL: {}" > /etc/hosts.allow'.format(allowed_hosts))

        # 3.4.3 Ensure /etc/hosts.deny is configured
        exec_shell('echo "ALL: ALL" > /etc/hosts.deny')

    # 3.4.4 Ensure permissions on /etc/hosts.allow are configured
    exec_shell([
        'chown root:root /etc/hosts.allow',
        'chmod 644 /etc/hosts.allow'
    ])

    # 3.4.5 Ensure permissions on /etc/hosts.deny are configured
    exec_shell([
        'chown root:root /etc/hosts.deny',
        'chmod 644 /etc/hosts.deny'
    ])


def disable_uncommon_protocols():
    """3.5 Uncommon Network Protocols"""
    print("Disabling uncommon network protocols - 3.5")
    
    modules = [
        'dccp', 'sctp', 'rds', 'tipc'
    ]
    prop = PropertyFile('/etc/modprobe.d/CIS.conf', ' ')
    for mod in modules:
        prop.override({'install {}'.format(mod): '/bin/true'})
    prop.write()



def iptables_boot():                                #final 3.5.1.1 
    
    print("Configure IPv4 iptables - 3.5.1.1, 3.5.1.2")
    
    PropertyFile('/etc/sysconfig/iptables_rules.sh', '').override({
        '#!/bin/sh': '',
        'yum install iptables': '',
        'yum install iptables-services': '',
    }).write()
    PropertyFile('/etc/sysconfig/iptables_rules.sh', '').override({
        'systemctl enable iptables': '',
        'systemctl start iptables': '',
    }).write()
    PropertyFile('/etc/sysconfig/iptables_rules.sh', '').override({
        'iptables -F': '',               
        'iptables -P INPUT DROP': '',
        'iptables -P OUTPUT DROP': '',
    }).write()
    PropertyFile('/etc/sysconfig/iptables_rules.sh', '').override({
        'iptables -P FORWARD DROP': '',
    }).write()
    PropertyFile('/etc/sysconfig/iptables_rules.sh', '').override({
        'iptables -A INPUT -i lo -j ACCEPT': '',
        'iptables -A OUTPUT -o lo -j ACCEPT': '',
    }).write()
    PropertyFile('/etc/sysconfig/iptables_rules.sh', '').override({
        'iptables -A INPUT -s 127.0.0.0/8 -j DROP': '',
    }).write()
    PropertyFile('/etc/sysconfig/iptables_rules.sh', '').override({
        'iptables -A OUTPUT -p tcp -m state --state NEW,ESTABLISHED -j ACCEPT': '',
        'iptables -A OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT': '',
    }).write()
    PropertyFile('/etc/sysconfig/iptables_rules.sh', '').override({
        'iptables -A OUTPUT -p icmp -m state --state NEW,ESTABLISHED -j ACCEPT': '',
    }).write()
    PropertyFile('/etc/sysconfig/iptables_rules.sh', '').override({
        'iptables -A INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT': '',
        'iptables -A INPUT -p udp -m state --state ESTABLISHED -j ACCEPT': '',
    }).write()
    PropertyFile('/etc/sysconfig/iptables_rules.sh', '').override({
        'iptables -A INPUT -p icmp -m state --state ESTABLISHED -j ACCEPT': '',
    }).write()
    PropertyFile('/etc/sysconfig/iptables_rules.sh', '').override({
        'iptables -A INPUT -p tcp --dport 22 -m state --state NEW -j ACCEPT': '',  
    }).write()    
    PropertyFile('/etc/sysconfig/iptables_rules.sh', '').override({
        'service iptables save': '',
        'iptables-save': '',
    }).write()

    

def ip6tables_boot():                                #final 3.5.2.1 

    print("Configure IPv6 ip6tables - 3.5.2.1, 3.5.2.2")
    
    
    PropertyFile('/etc/sysconfig/ip6tables_rules.sh', '').override({
        '#!/bin/sh': '',
        'systemctl enable ip6tables': '',
        'systemctl start ip6tables': '',
        'yum install ip6tables': '',
        'yum install ip6tables-services': ''
    }).write()
        
    PropertyFile('/etc/sysconfig/ip6tables_rules.sh', '').override({
        'ip6tables -F': '',
        'ip6tables -P INPUT DROP': ''
    }).write()
    PropertyFile('/etc/sysconfig/ip6tables_rules.sh', '').override({
        'ip6tables -P OUTPUT DROP': '',
        'ip6tables -P FORWARD DROP': '',
    }).write()
    PropertyFile('/etc/sysconfig/ip6tables_rules.sh', '').override({
        'ip6tables -A INPUT -i lo -j ACCEPT': '',
        'ip6tables -A OUTPUT -o lo -j ACCEPT': '',
    }).write()    
    PropertyFile('/etc/sysconfig/ip6tables_rules.sh', '').override({
        'ip6tables -A INPUT -s ::1 -j DROP': ''
    }).write()
        
    PropertyFile('/etc/sysconfig/ip6tables_rules.sh', '').override({  
        'ip6tables-save': '',
        'service ip6tables save': '',
        'find /var/log -type f -exec chmod g-wx,o-rwx {} +': ''  # --> this line 4.2.4
        
    }).write()



    
def boot_time_iptables():                                #final 3.5.2.1 
    
    
    PropertyFile('/etc/systemd/system/boot_time_iptables.service', '').override({
        '[Unit]': '',
        'Description=iptables.': ''
    }).write()
    
    PropertyFile('/etc/systemd/system/boot_time_iptables.service', '').override({
        '[Service]': ''
    }).write()
    
    PropertyFile('/etc/systemd/system/boot_time_iptables.service', '').override({
        'Type=simple': '',
        'ExecStart=/bin/bash /etc/sysconfig/iptables_rules.sh': ''
    }).write()
        
    PropertyFile('/etc/systemd/system/boot_time_iptables.service', '').override({
        '[Install]': '',
        'WantedBy=multi-user.target': ''
    }).write()
    
    exec_shell([
        'chmod 644 /etc/systemd/system/boot_time_iptables.service',
        'systemctl enable boot_time_iptables.service'
    ])



    

def boot_time_ip6tables():                                #final 3.5.2.1 
    
    PropertyFile('/etc/systemd/system/boot_time_ip6tables.service', '').override({
        '[Unit]': '',
        'Description=iptables.': ''
    }).write()
    
    PropertyFile('/etc/systemd/system/boot_time_ip6tables.service', '').override({
        '[Service]': ''
    }).write()
    
    PropertyFile('/etc/systemd/system/boot_time_ip6tables.service', '').override({
        'Type=simple': '',
        'ExecStart=/bin/bash /etc/sysconfig/ip6tables_rules.sh': ''
    }).write()
    
    PropertyFile('/etc/systemd/system/boot_time_ip6tables.service', '').override({
        '[Install]': '',
        'WantedBy=multi-user.target': ''
    }).write()
    
    exec_shell([
        'chmod 644 /etc/systemd/system/boot_time_ip6tables.service',
        'systemctl enable boot_time_ip6tables.service'
    ])




def configure_rsyslog():
    """4.2.1 Configure rsyslog"""
    print("Configure rsyslog - 4.2.1")
    Package('rsyslog').install()

    PropertyFile('/etc/rsyslog.conf', ' ').override({
        '*.emerg': ':omusrmsg:*',
        'mail.*': '-/var/log/mail',
        'mail.info': '-/var/log/mail.info',
        'mail.warning': '-/var/log/mail.warn',
        'mail.err': '/var/log/mail.err',
        'news.crit': '-/var/log/news/news.crit',
        'news.err': '-/var/log/news/news.err',
        'news.notice': '-/var/log/news/news.notice',
        '*.=warning;*.=err': '-/var/log/warn',
        '*.crit': '/var/log/warn',
        '*.*;mail.none;news.none': '-/var/log/messages',
        'local0,local1.*': '-/var/log/localmessages',
        'local2,local3.*': '-/var/log/localmessages',
        'local4,local5.*': '-/var/log/localmessages',
        'local6,local7.*': '-/var/log/localmessages ',
        '$FileCreateMode': '0640'
    }).write()


def configure_log_file_permissions():
    """4.2.4 Ensure permissions on all logfiles are configured"""
    print("Configuring log file permissions - 4.2.4")
    exec_shell([r'find /var/log -type f -exec chmod g-wx,o-rwx {} +'])


def configure_cron():
    """5.1 Configure cron"""
    print("Setting permissions on cron - 5.1.1 - 5.1.18")
    # 5.1.1 Ensure cron daemon is enabled
    Service('crond').enable()

    # 5.1.2 - 5.1.8
    exec_shell([
        'chown root:root /etc/crontab',
        'chmod og-rwx /etc/crontab',
        'chown root:root /etc/cron.hourly',
        'chmod og-rwx /etc/cron.hourly',
        'chown root:root /etc/cron.daily',
        'chmod og-rwx /etc/cron.daily',
        'chown root:root /etc/cron.weekly',
        'chmod og-rwx /etc/cron.weekly',
        'chown root:root /etc/cron.monthly',
        'chmod og-rwx /etc/cron.monthly',
        'chown root:root /etc/cron.d',
        'chmod og-rwx /etc/cron.d',
        'rm -f /etc/cron.deny',
        'rm -f /etc/at.deny',
        'touch /etc/cron.allow',
        'touch /etc/at.allow',
        'chmod og-rwx /etc/cron.allow',
        'chmod og-rwx /etc/at.allow',
        'chown root:root /etc/cron.allow',
        'chown root:root /etc/at.allow'
    ])


def configure_sshd():
    """5.2 SSH Server Configuration"""
    print("Hardening SSH Server Configuration - 5.2.1 - 5.2.16")
    # 5.2.1 Ensure permissions on /etc/ssh/sshd_config are configured
    exec_shell([
        'chown root:root /etc/ssh/sshd_config',
        'chmod og-rwx /etc/ssh/sshd_config'
    ])

    # 5.2.2 - 5.2.16
    PropertyFile('/etc/ssh/sshd_config', ' ').override({
        'Protocol': '2',
        'LogLevel': 'INFO',
        'X11Forwarding': 'no',
        'MaxAuthTries': '4',
        'IgnoreRhosts': 'yes',
        'HostbasedAuthentication': 'no',
        'PermitRootLogin': 'no',
        'PermitEmptyPasswords': 'no',
        'PermitUserEnvironment': 'no',
        'Ciphers': 'aes256-ctr,aes192-ctr,aes128-ctr',
        'MACs': 'hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com,umac-128-etm@openssh.com,hmac-sha2-512,hmac-sha2-256,umac-128@openssh.com',
        'ClientAliveInterval': '300',
        'ClientAliveCountMax': '0',
        'LoginGraceTime': '60',
        'AllowUsers': 'ec2-user',
        'Banner': '/etc/issue.net',
        'KexAlgorithms': 'curve25519-sha256,curve25519-sha256@libssh.org,diffie-hellman-group14-sha256,diffie-hellman-group16-sha512,diffie-hellman-group18-sha512,ecdh-sha2-nistp521,ecdh-sha2-nistp384,ecdh-sha2-nistp256,diffie-hellman-group-exchange-sha256'
        
    }).write()                       
    
   
def configure_pam():
    """5.3 Configure PAM"""
    print("Setting PAM up - 5.3")

    def convert_password(line):
        if password_unix_re.match(line):
            if 'remember=5' not in line:
                line += ' remember=5'
            if 'sha512' not in line:
                line += ' sha512'
        return line
    password_unix_re = re.compile(r'^password\s+sufficient\s+pam_unix.so')

    password_auth_content = get_string_asset('/etc/pam.d/password-auth')
    password_auth_content += exec_shell([
        'cat /etc/pam.d/password-auth | grep -v "^auth"'
    ])
    password_auth_content = '\n'.join([
        convert_password(line) for line in password_auth_content.splitlines()
    ])

    with open('/etc/pam.d/password-auth-local', 'w') as f:
        f.write(password_auth_content)

    exec_shell(['ln -sf /etc/pam.d/password-auth-local /etc/pam.d/password-auth'])

    system_auth_content = get_string_asset('/etc/pam.d/system-auth')
    system_auth_content += exec_shell([
        'cat /etc/pam.d/system-auth | grep -v "^auth"'
    ])
    system_auth_content = '\n'.join([
        convert_password(line) for line in system_auth_content.splitlines()
    ])
    with open('/etc/pam.d/system-auth-local', 'w') as f:
        f.write(system_auth_content)

    exec_shell(
        ['ln -sf /etc/pam.d/system-auth-local /etc/pam.d/system-auth'])

    PropertyFile('/etc/security/pwquality.conf', '=').override({
        'minlen': '14',
        'dcredit': '-1',
        'ucredit': '-1',
        'ocredit': '-1',
        'lcredit': '-1'
    }).write()


def configure_password_parmas():
    """5.4.1 Set Shadow Password Suite Parameters"""
    PropertyFile('/etc/login.defs', '\t').override({
        'PASS_MAX_DAYS': '90',
        'PASS_MIN_DAYS': '7',
        'PASS_WARN_AGE': '7'
    }).write()

    exec_shell([
        'useradd -D -f 30'
    ])


def configure_umask():
    """5.4.3, 5.4.4"""
    print("Configuring umask - 5.4.3 - 5.4.5")
    umask_reg = r'^(\s*)umask\s+[0-7]+(\s*)$'

    bashrc = exec_shell([
        'cat /etc/bashrc | sed -E "s/{}/\\1umask 027\\2/g"'.format(umask_reg)
    ])
    File('/etc/bashrc').write(bashrc)
    
    PropertyFile('/etc/bashrc', '=').override({'TMOUT': "600"}).write()   #changs added 5.4.5

    profile = exec_shell([
        'cat /etc/profile | sed -E "s/{}/\\1umask 027\\2/g"'.format(
            umask_reg)
    ])
    File('/etc/profile').write(profile)
    
    PropertyFile('/etc/profile', '=').override({'TMOUT': "600"}).write()  #changs added 5.4.5


def configure_su():
    """5.5 Ensure access to the su command is restricted"""
    print("Restricting access to the su command - 5.5")
    File('/etc/pam.d/su').write(get_string_asset('/etc/pam.d/su'))
    exec_shell('usermod -aG wheel root')


#  1.6.1.2 and 1.6.1.3  

def selinux():           
    print("Configuring SELINUX - 1.6.1.2, 1.6.1.3")
    
    PropertyFile('/etc/selinux/config', '=').override({
        
        'SELINUX': 'enforcing',
        'SELINUXTYPE': 'targeted'
        
        
    }).write() 

#4.1.3 

def configure_grub():			
    """4.1.3 grub """
    print("audit grub - 4.1.3")
    # 4.1.3 Ensure auditing for processes that start prior to auditd is enabled
    
    PropertyFile('/etc/default/grub', '').override({
        'GRUB_CMDLINE_LINUX="audit=1"': '',
    }).write()
    


    exec_shell('grub2-mkconfig -o /boot/grub2/grub.cfg')    


def audit():
    
    print("audit - 4.1.4 to 4.1.8")
    
    PropertyFile('/etc/audit/audit.rules', " ").override({
        
        #4.1.4
        '-a always,exit -F arch=b64 -S adjtimex -S settimeofday -k time-change': ' ',
        '-a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-change': ' ',
        '-a always,exit -F arch=b64 -S clock_settime -k time-change': ' ',
        '-a always,exit -F arch=b32 -S clock_settime -k time-change': ' ',
        '-w /etc/localtime -p wa -k time-change': ' ',
        
        #4.1.5
        '-w /etc/group -p wa -k identity': ' ',
        '-w /etc/passwd -p wa -k identity': ' ',
        '-w /etc/gshadow -p wa -k identity': ' ',
        '-w /etc/shadow -p wa -k identity': ' ',
        '-w /etc/security/opasswd -p wa -k identity': ' ',
        
        
        #4.1.6
        '-a always,exit -F arch=b64 -S sethostname -S setdomainname -k system-locale': ' ',
        '-a always,exit -F arch=b32 -S sethostname -S setdomainname -k system-locale': ' ',
        '-w /etc/issue -p wa -k system-locale': ' ',
        '-w /etc/issue.net -p wa -k system-locale': ' ',
        '-w /etc/hosts -p wa -k system-locale': ' ',
        '-w /etc/sysconfig/network -p wa -k system-locale': ' ',
        '-w /etc/sysconfig/network-scripts/ -p wa -k system-locale': ' ',
        
        
        #4.1.7
        '-w /etc/selinux/ -p wa -k MAC-policy': ' ',
        '-w /usr/share/selinux/ -p wa -k MAC-policy': ' ',
        
        
        #4.1.8
        '-w /var/log/lastlog -p wa -k logins': '',
        '-w /var/run/faillock/ -p wa -k logins': '',
        
        
        #4.1.9
        '-w /var/run/utmp -p wa -k session': ' ',
        '-w /var/log/wtmp -p wa -k logins': ' ',
        '-w /var/log/btmp -p wa -k logins': ' ',
        
        #4.1.10
        '-a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod': ' ',
        '-a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod': ' ',
        '-a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod': ' ',
        '-a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod': ' ',
        '-a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod': ' ',
        '-a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod': ' ',
        
        #4.1.11
        '-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access': ' ',
        '-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access': ' ',
        '-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access': ' ',
        '-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access': ' ',
        
        #4.1.13
        '-a always,exit -F arch=b64 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts': ' ',
        '-a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts': ' ',
        
      
        #4.1.14
        '-a always,exit -F arch=b64 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete': ' ',
        '-a always,exit -F arch=b32 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete': ' ',
        
        #4.1.15
        '-w /etc/sudoers -p wa -k scope': ' ',
        '-w /etc/sudoers.d/ -p wa -k scope': ' ',
        
        #4.1.16
        '-w /var/log/sudo.log -p wa -k actions': ' ',
        
        #4.1.17
        '-w /sbin/insmod -p x -k modules': ' ',
        '-w /sbin/rmmod -p x -k modules': ' ',
        '-w /sbin/modprobe -p x -k modules': ' ',
        '-a always,exit -F arch=b64 -S init_module -S delete_module -k modules': ' '

    }).write()
    
    
     #4.1.18
    exec_shell(" echo '-e 2' >> /etc/audit/audit.rules")    #--> need only once
    
    
     
    PropertyFile('/etc/audit/rules.d/audit.rules', " ").override({   
        
        #4.1.5
        '-w /etc/group -p wa -k identity': ' ',
        '-w /etc/passwd -p wa -k identity': ' ',
        '-w /etc/gshadow -p wa -k identity': ' ',
        '-w /etc/shadow -p wa -k identity': ' ',
        '-w /etc/security/opasswd -p wa -k identity': ' ',

        
        #4.1.6
        '-a always,exit -F arch=b64 -S sethostname -S setdomainname -k system-locale': ' ',
        '-a always,exit -F arch=b32 -S sethostname -S setdomainname -k system-locale': ' ',
        '-w /etc/issue -p wa -k system-locale': ' ',
        '-w /etc/issue.net -p wa -k system-locale': ' ',
        '-w /etc/hosts -p wa -k system-locale': ' ',
        '-w /etc/sysconfig/network -p wa -k system-locale': ' ',
        '-w /etc/sysconfig/network-scripts/ -p wa -k system-locale': ' ',
        
        #4.1.7
        '-w /etc/selinux/ -p wa -k MAC-policy': ' ',
        '-w /usr/share/selinux/ -p wa -k MAC-policy': ' ',
        
        
        
        #4.1.8
        '-w /var/log/lastlog -p wa -k logins': '',
        '-w /var/run/faillock/ -p wa -k logins': '',
        
        
        
        #4.1.9
        '-w /var/run/utmp -p wa -k session': ' ',
        '-w /var/log/wtmp -p wa -k logins': ' ',
        '-w /var/log/btmp -p wa -k logins': ' ',
        
        
        #4.1.10
        '-a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod': ' ',
        '-a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod': ' ',
        '-a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod': ' ',
        '-a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod': ' ',
        '-a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod': ' ',
        '-a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod': ' ',
        
        
        
        #4.1.11
        '-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access': ' ',
        '-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access': ' ',
        '-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access': ' ',
        '-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access': ' ',
        
        
        
        #4.1.13
        '-a always,exit -F arch=b64 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts': ' ',
        '-a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts': ' ',
        
        
        
        #4.1.14
        '-a always,exit -F arch=b64 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete': ' ',
        '-a always,exit -F arch=b32 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete': ' ',
        
        
        
        #4.1.15
        '-w /etc/sudoers -p wa -k scope': ' ',
        '-w /etc/sudoers.d/ -p wa -k scope': ' ',
        
        
        #4.1.16
        '-w /var/log/sudo.log -p wa -k actions': ' ',
        
        
        #4.1.17
        
        '-w /sbin/insmod -p x -k modules': ' ',
        '-w /sbin/rmmod -p x -k modules': ' ',
        '-w /sbin/modprobe -p x -k modules': ' ',
        '-a always,exit -F arch=b64 -S init_module -S delete_module -k modules': ' '
    
    
    }).write()
    
    

    #4.1.18
    exec_shell(" echo '-e 2' >> /etc/audit/rules.d/audit.rules")    #--> need only once
    
    
    
def audit_2():
    '''Ensure system is disabled when audit logs are full - 4.1.1.2, 4.1.1.3'''
    print("Ensure system is disabled when audit logs are full - 4.1.1.2, 4.1.1.3")
    #4.1.1.2
    
    PropertyFile('/etc/audit/auditd.conf', '=').override({
        'space_left_action': 'email',
        'action_mail_acct': 'root',
        'admin_space_left_action': 'halt',
       
        'max_log_file_action': 'keep_logs'   #--> 4.1.1.3
        
    }).write()
    
    
def tmp_ftab():                 # 1.1.2 
    print("Ensure /tmp is configured - 1.1.2 \n Ensure nodev option set on /tmp partition - 1.1.3 \n Ensure nosuid option set on /tmp partition - 1.1.4 \n Ensure noexec option set on /tmp partition - 1.1.5")
    
    PropertyFile('/etc/fstab', '').override({
        'tmpfs /tmp tmpfs defaults,rw,nosuid,nodev,noexec,relatime 0 0': ''
    }).write()
    
   
    
def noexec1():             #1.1.17
    print("Ensure noexec option set on /dev/shm partition - 1.1.17")

    PropertyFile('/etc/fstab', '').override({
        'tmpfs /dev/shm tmpfs defaults,nodev,nosuid,noexec 0 0': ''
    }).write()
    
    
    exec_shell([
        'mount -o remount,noexec /dev/shm'
    ])
    
def log1():                 #4.2.4
    print("Ensure permissions on all logfiles are configured  - 4.2.4")
    exec_shell('find /var/log -type f -exec chmod g-wx,o-rwx {} +')
    
    
    
def disable_ipv6():             #3.6 disable IPv6
    print("Disable ipv6 - 3.6")
    
    PropertyFile('/etc/default/grub','=').override({
        'GRUB_CMDLINE_LINUX': '"ipv6.disable=1"'
    })
    
    exec_shell('grub2-mkconfig -o /boot/grub2/grub.cfg')
    



    

def main():
    parser = argparse.ArgumentParser(
        description='A script to harden Amazon Linux instance.')

    # The Amazon Time Sync Service is available through NTP
    # at the 169.254.169.123 IP address for any instance running in a VPC.
    # https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/set-time.html
    parser.add_argument('--time', metavar='<time server>', default ='169.254.169.123',
                        help='Specify the upstream time server.')
    parser.add_argument('--chrony', action='store', type=bool, default=True,
                        help='Use chrony for time synchronization')
    parser.add_argument('--no-backup', action='store_true',
                        help='Automatic config backup is disabled')
    parser.add_argument('--clients', nargs='+', metavar='<allowed clients>',
                        help='Specify a comma separated list of hostnames and host IP addresses.')
    parser.add_argument('-v', '--verbose', action='store_true',
                        help='Display details including debugging output etc.')
    parser.add_argument('--disable-tcp-wrappers', action='store_true',
                        help='disable tcp-wrappers')
    parser.add_argument('--disable-pam', action='store_true',
                        help='disable pam')
    parser.add_argument('--disable-iptables', action='store_true',
                        help='disable iptables')
    parser.add_argument('--disable-mount-options', action='store_true',
                        help='disable set mount options')

    args = parser.parse_args()

    if args.verbose:
        logging.basicConfig(level=logging.INFO)
    else:
        logging.basicConfig(level=logging.WARN)

    logging.info(
        '[Config] Upstream time server is set as "%s"', args.time)
    if args.chrony:
        logging.info(
            '[Config] chrony will be used for time synchronization')
    else:
        logging.info(
            '[Config] ntp will be used for time synchronization')
    if args.clients:
        logging.info('[Config] Allowed clients are set as %s',
            args.clients)

    if args.no_backup:
        logging.info('[Config] Automatic config backup is disabled')
        set_backup_enabled(False)
        
    

    # 1 Initial Setup
    disable_unused_filesystems()
    #if not args.disable_mount_options:
        #set_mount_options()
    ensure_sticky_bit()
    #disable_automounting()
    enable_aide()
    secure_boot_settings()
    apply_process_hardenings()
    configure_warning_banners()
    ensure_updated()
   

    # 2 Services
    disable_inetd_services()
    #configure_time_synchronization(args.time, chrony=args.chrony)
    remove_x11_packages()
    disable_special_services()
    configure_mta()
    remove_insecure_clients()

    # 3 Network Configuration
    configure_host_network_params()
    configure_network_params()
    configure_ipv6_params()
    if not args.disable_tcp_wrappers:
        configure_tcp_wrappers(args.clients)
    disable_uncommon_protocols()
    # if not args.disable_iptables:
    #     configure_iptables()
    #     #configure_iptables_new()

    # 4 Logging and Auditing
    configure_rsyslog()
    configure_log_file_permissions()

    # 5 Access, Authentication and Authorization
    configure_cron()
    configure_sshd()
    if not args.disable_pam:
        configure_pam()
    configure_password_parmas()
    configure_umask()
    configure_su()

    #new functions
    
    selinux()                   #  1.6.1.2 and 1.6.1.3   
    configure_grub()            #4.1.3  
    #audit related rules function
    
    audit()             
    audit_2()           
    log1()              
    tmp_ftab()          
    disable_ipv6()      
    noexec1()           
    iptables_boot()     
    ip6tables_boot()
    boot_time_iptables()
    boot_time_ip6tables()
    noexec1()           

if __name__ == '__main__':
    main()
